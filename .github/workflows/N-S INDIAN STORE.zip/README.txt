N-S INDIAN STORES — FRONT-END DEMO

FILES
1. index.html  - website structure
2. style.css   - design and responsive layout
3. script.js   - demo features and browser storage

HOW TO RUN
1. Keep all three files in the same folder.
2. Double-click index.html, or open it in Chrome.
3. No installation is required.

DEMO FEATURES
- State, city and store dropdowns
- Product categories and search
- Cart with quantity controls
- Customer, shopkeeper and delivery-boy demo login roles
- Shopkeeper can add and delete demo products
- Demo order placement and Cash on Delivery / simulated online payment selection
- Orders and user details stored in this browser using localStorage

IMPORTANT — BEFORE A REAL PUBLIC LAUNCH
This is a front-end prototype only. It does NOT include a real database, secure authentication,
OTP verification, live delivery tracking, seller verification, inventory sync, order notifications,
payment gateway, refunds, tax invoices or admin panel. The online payment option is only a demo
selection and does not collect money. Do not collect real customer data or payments with this demo.

For production, connect a backend (for example Node.js + Express), a database (PostgreSQL or
MongoDB), secure password/OTP authentication, role-based access, and a payment gateway account.
A real payment gateway must be integrated and tested securely before accepting payments.
