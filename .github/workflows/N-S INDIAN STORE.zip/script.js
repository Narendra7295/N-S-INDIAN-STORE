const $ = (id) => document.getElementById(id);
const demoProducts = [
 {id:1,name:"Fresh potatoes",category:"Groceries",price:30,unit:"1 kg",qty:45,store:"Shree General Store",city:"Kuchaman",emoji:"🥔",description:"Fresh daily stock"},
 {id:2,name:"Basmati rice",category:"Groceries",price:95,unit:"1 kg",qty:25,store:"Shree General Store",city:"Kuchaman",emoji:"🍚",description:"Premium quality rice"},
 {id:3,name:"Red apples",category:"Fruits",price:140,unit:"1 kg",qty:18,store:"Fresh Basket",city:"Jaipur",emoji:"🍎",description:"Fresh seasonal apples"},
 {id:4,name:"Full cream milk",category:"Dairy",price:34,unit:"500 ml",qty:30,store:"Fresh Basket",city:"Jaipur",emoji:"🥛",description:"Pasteurised milk"},
 {id:5,name:"Tea biscuits",category:"Snacks",price:25,unit:"1 pack",qty:60,store:"Shree General Store",city:"Kuchaman",emoji:"🍪",description:"Crunchy tea-time snack"},
 {id:6,name:"Dishwash liquid",category:"Household",price:89,unit:"500 ml",qty:14,store:"City Mart",city:"Ajmer",emoji:"🧽",description:"Kitchen cleaning liquid"},
 {id:7,name:"Shampoo",category:"Personal Care",price:120,unit:"180 ml",qty:20,store:"City Mart",city:"Ajmer",emoji:"🧴",description:"Everyday hair care"},
 {id:8,name:"Notebook",category:"Stationery",price:45,unit:"1 piece",qty:35,store:"Student Corner",city:"Kuchaman",emoji:"📒",description:"Single-line notebook"}
];
let products = [...demoProducts, ...JSON.parse(localStorage.getItem("nsProducts") || "[]")];
let cart = JSON.parse(localStorage.getItem("nsCart") || "[]");
let orders = JSON.parse(localStorage.getItem("nsOrders") || "[]");
let activeCategory = "All", activeRole = "customer", currentUser = JSON.parse(localStorage.getItem("nsUser") || "null");

const cities = {
 "Rajasthan":["Kuchaman","Jaipur","Ajmer","Jodhpur","Bikaner","Nagaur","Sikar","Udaipur"],
 "Delhi":["New Delhi","Delhi"],
 "Haryana":["Gurugram","Faridabad","Hisar","Rohtak"],
 "Uttar Pradesh":["Agra","Lucknow","Noida","Kanpur"],
 "Gujarat":["Ahmedabad","Surat","Vadodara","Rajkot"],
 "Maharashtra":["Mumbai","Pune","Nagpur","Nashik"],
 "Punjab":["Amritsar","Ludhiana","Jalandhar"],
 "Madhya Pradesh":["Bhopal","Indore","Gwalior","Jabalpur"]
};
function save(){localStorage.setItem("nsProducts",JSON.stringify(products.filter(p=>p.custom)));localStorage.setItem("nsCart",JSON.stringify(cart));localStorage.setItem("nsOrders",JSON.stringify(orders));}
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2400);}
function showModal(id){$(id).classList.add("show");}
function hideModal(id){$(id).classList.remove("show");}
function renderProducts(){
 const term=$("searchInput").value.toLowerCase(), city=$("citySelect").value, store=$("storeSelect").value;
 let list=products.filter(p=>(activeCategory==="All"||p.category===activeCategory)&&(!term||(p.name+" "+p.store+" "+p.category).toLowerCase().includes(term))&&(!city||p.city===city)&&(!store||p.store===store));
 $("productsTitle").textContent=activeCategory==="All"?"Popular products":activeCategory;
 $("resultCount").textContent=`${list.length} products`;
 $("productGrid").innerHTML=list.length?list.map(p=>`<article class="product-card"><div class="product-visual">${p.emoji||"📦"}</div><h3>${escapeHtml(p.name)}</h3><div class="details">${escapeHtml(p.store)} · ${escapeHtml(p.description||"")}</div><div class="price-row"><div><div class="price">₹${Number(p.price).toFixed(0)}</div><div class="unit">${escapeHtml(p.unit||"per item")}</div></div><button class="add-btn" onclick="addToCart(${p.id})">+ Add</button></div><div class="stock">${p.qty>0?`${p.qty} available`:"Out of stock"}</div></article>`).join(""):`<div class="empty">No products found. Try another category or location.</div>`;
}
function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function addToCart(id){const p=products.find(x=>x.id===id);if(!p||p.qty<=0)return toast("This item is currently out of stock.");const found=cart.find(x=>x.id===id);if(found){if(found.qty>=p.qty)return toast("Available stock limit reached.");found.qty++;}else cart.push({id,qty:1});save();renderCartCount();toast("Added to cart.");}
function renderCartCount(){$("cartCount").textContent=cart.reduce((s,x)=>s+x.qty,0);}
function renderCart(){
 const lines=cart.map(c=>{const p=products.find(x=>x.id===c.id);return p?`<div class="cart-line"><div><b>${escapeHtml(p.name)}</b><small>₹${p.price} × ${c.qty}</small></div><div class="qty-controls"><button onclick="changeQty(${p.id},-1)">−</button><b>${c.qty}</b><button onclick="changeQty(${p.id},1)">+</button></div><b>₹${p.price*c.qty}</b></div>`:"";}).join("");
 $("cartItems").innerHTML=lines||'<div class="empty">Your cart is empty.</div>';
 $("cartTotal").textContent="₹"+cart.reduce((s,c)=>{const p=products.find(x=>x.id===c.id);return s+(p?p.price*c.qty:0)},0);
}
function changeQty(id,d){const c=cart.find(x=>x.id===id),p=products.find(x=>x.id===id);if(!c)return;c.qty+=d;if(c.qty<=0)cart=cart.filter(x=>x.id!==id);else if(p&&c.qty>p.qty){c.qty=p.qty;toast("Available stock limit reached.");}save();renderCart();renderCartCount();}
function openLogin(role="customer"){activeRole=role;document.querySelectorAll(".role").forEach(b=>b.classList.toggle("active",b.dataset.role===role));$("loginTitle").textContent=role==="customer"?"Customer login":role==="shopkeeper"?"Shopkeeper login":"Delivery boy login";showModal("loginModal");}
document.querySelectorAll(".role").forEach(b=>b.addEventListener("click",()=>openLogin(b.dataset.role)));
$("loginForm").addEventListener("submit",e=>{e.preventDefault();currentUser={name:$("loginName").value.trim(),phone:$("loginPhone").value.trim(),role:activeRole};localStorage.setItem("nsUser",JSON.stringify(currentUser));hideModal("loginModal");toast(`Welcome, ${currentUser.name}!`);if(activeRole==="shopkeeper")openShop();else if(activeRole==="delivery")showInfo("Delivery dashboard","Your delivery tasks will appear here when the live delivery system is connected.");});
function openShop(){showModal("shopModal");renderSellerProducts();}
function renderSellerProducts(){const own=products.filter(p=>p.custom&&p.owner===currentUser?.phone);$("sellerProducts").innerHTML=own.length?own.map(p=>`<div class="seller-row"><div><b>${escapeHtml(p.name)}</b><small>₹${p.price} · Stock: ${p.qty} · ${escapeHtml(p.store)}</small></div><button class="danger-btn" onclick="deleteProduct(${p.id})">Delete</button></div>`).join(""):"<p class='tiny'>You have not added any products yet.</p>";}
$("productForm").addEventListener("submit",e=>{e.preventDefault();if(!currentUser||currentUser.role!=="shopkeeper"){toast("Please login as shopkeeper first.");return;}const p={id:Date.now(),name:$("pName").value.trim(),category:$("pCategory").value,price:Number($("pPrice").value),qty:Number($("pQty").value),unit:$("pUnit").value.trim()||"1 item",store:$("pStore").value.trim(),city:$("citySelect").value||"Kuchaman",description:$("pDescription").value.trim(),emoji:"📦",custom:true,owner:currentUser.phone};products.push(p);save();e.target.reset();renderProducts();renderSellerProducts();toast("Product added to the demo store.");});
function deleteProduct(id){products=products.filter(p=>p.id!==id);save();renderProducts();renderSellerProducts();toast("Product removed.");}
$("placeOrder").addEventListener("click",()=>{if(!cart.length)return toast("Your cart is empty.");if(!currentUser||currentUser.role!=="customer")return toast("Please login as a customer to place an order.");const method=document.querySelector('input[name="payment"]:checked').value;const total=cart.reduce((s,c)=>{const p=products.find(x=>x.id===c.id);return s+(p?p.price*c.qty:0)},0);orders.unshift({id:"NS"+Date.now().toString().slice(-7),date:new Date().toLocaleString(),total,method,status:"Demo order placed",items:cart.map(c=>({...c,name:products.find(p=>p.id===c.id)?.name}))});cart.forEach(c=>{const p=products.find(x=>x.id===c.id);if(p)p.qty=Math.max(0,p.qty-c.qty)});cart=[];save();renderCart();renderCartCount();renderProducts();hideModal("cartModal");toast("Demo order placed successfully.");});
function showInfo(title,body){$("infoContent").innerHTML=`<span class="eyebrow">N-S INDIAN STORES</span><h2>${title}</h2>${body}`;showModal("infoModal");}
function openOrders(){const body=orders.length?orders.map(o=>`<div class="cart-line"><div><b>Order ${o.id}</b><small>${o.date} · ${o.method} · ${o.status}</small></div><b>₹${o.total}</b></div>`).join(""):"<p class='muted'>You have no orders yet.</p>";showInfo("Your orders",body);}
document.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".side-link").forEach(x=>x.classList.remove("active"));b.classList.add("active");$("sidebar").classList.remove("open");$("scrim").classList.remove("show");if(b.dataset.view==="orders")openOrders();if(b.dataset.view==="profile")showInfo("My profile",currentUser?`<p><b>Name:</b> ${escapeHtml(currentUser.name)}<br><b>Mobile:</b> ${escapeHtml(currentUser.phone)}<br><b>Account type:</b> ${escapeHtml(currentUser.role)}</p>`:"<p class='muted'>Please login to view your profile.</p>");if(b.dataset.view==="settings")showInfo("Settings",'<p class="muted">Account preferences and notifications will be available in the full version.</p>');if(b.dataset.view==="home")window.scrollTo({top:0,behavior:"smooth"});}));
$("loginOpen").onclick=()=>openLogin("customer");$("shopLoginSide").onclick=()=>openLogin("shopkeeper");$("deliveryLoginSide").onclick=()=>openLogin("delivery");$("sellerCta").onclick=()=>currentUser?.role==="shopkeeper"?openShop():openLogin("shopkeeper");$("cartOpen").onclick=()=>{renderCart();showModal("cartModal");};
$("searchInput").addEventListener("input",renderProducts);
$("stateSelect").addEventListener("change",()=>{const list=cities[$("stateSelect").value]||[];$("citySelect").innerHTML='<option value="">All cities</option>'+list.map(c=>`<option>${c}</option>`).join("");$("storeSelect").innerHTML='<option value="">All stores</option>';renderProducts();});
$("citySelect").addEventListener("change",()=>{const city=$("citySelect").value;const stores=[...new Set(products.filter(p=>!city||p.city===city).map(p=>p.store))];$("storeSelect").innerHTML='<option value="">All stores</option>'+stores.map(s=>`<option>${escapeHtml(s)}</option>`).join("");$("locationHint").textContent=city?`Showing stores and products in ${city}.`:"Select a city to filter nearby stores.";renderProducts();});
$("storeSelect").addEventListener("change",renderProducts);
document.querySelectorAll(".category").forEach(b=>b.addEventListener("click",()=>{activeCategory=b.dataset.category;document.querySelectorAll(".category").forEach(x=>x.classList.toggle("active",x===b));renderProducts();}));
$("allProductsBtn").onclick=()=>{activeCategory="All";document.querySelectorAll(".category").forEach(x=>x.classList.toggle("active",x.dataset.category==="All"));renderProducts();};
$("exploreBtn").onclick=()=>$("productGrid").scrollIntoView({behavior:"smooth"});
$("menuBtn").onclick=()=>{$("sidebar").classList.add("open");$("scrim").classList.add("show");};$("scrim").onclick=()=>{$("sidebar").classList.remove("open");$("scrim").classList.remove("show");};
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>hideModal(b.dataset.close));
document.querySelectorAll(".modal").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)m.classList.remove("show");}));
renderProducts();renderCartCount();
